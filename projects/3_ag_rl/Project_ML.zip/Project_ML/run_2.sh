echo '1'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 10 --pop 10
echo '2'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 10 --pop 25
echo '3'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 10 --pop 100
echo '1'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 30 --pop 10
echo '2'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 30 --pop 25
echo '3'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 30 --pop 100
echo '1'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 100 --pop 10
echo '2'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 100 --pop 25
echo '3'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 100 --pop 100
