python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 10 --pop 50
echo '10 gerações - população 100'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 10 --pop 100
echo '55 gerações - população 50'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 55 --pop 50
echo '55 gerações - população 100'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 55 --pop 100
echo '100 gerações - população 50'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 100 --pop 50
echo '100 gerações - população 100'
python pacman.py -p GPAgent -x 1 -n 11 --layout mediumClassic --gen 100 --pop 100
