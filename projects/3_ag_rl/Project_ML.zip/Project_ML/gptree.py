import math
import functools
import random

WALL = 0
CANDY = 1
EMPTY = 2
ENEMY = 3
PACMAN_POS = 4

GAME_ON = 0
GAME_OVER = 1

FUNCTIONS = ['+', '-', '*', '/']
DISTANCE_TO_NEAREST_GHOST = 'G'
DISTANCE_TO_NEAREST_PILL = 'P'
PLACE_COUNT = 'T'
CONSTANT = 'C'
PILLS_IN_DISTANCE = 'D'
GHOSTS_IN_DISTANCE = 'E'
DISTANCE_TO_NEAREST_CORNER = 'N'
DISTANCE_TO_NEAREST_POWER = 'O'
PREVENT_MOVEMENT_LOOP = 'L'
CORNER = 'R'

PACMAN_TERMINALS = [DISTANCE_TO_NEAREST_GHOST, DISTANCE_TO_NEAREST_PILL, PLACE_COUNT, PILLS_IN_DISTANCE,
                    GHOSTS_IN_DISTANCE, CONSTANT, DISTANCE_TO_NEAREST_POWER, CORNER, PREVENT_MOVEMENT_LOOP]
CONSTANT_MIN = -1
CONSTANT_MAX = 10
PRINT = True
# Allowed movements
PACMAN_MOVES = [[0, 1], [0, -1], [1, 0], [-1, 0]]
GHOST_MOVES = [[0, 1], [0, -1], [1, 0], [-1, 0]]

MAX_TREE_DEPTH = 3
TOURNAMENT_SIZE = 3
POPULATION_SIZE = 100
NUMBER_OF_GENERATIONS = 100
CROSSOVER_PROB = 0.7
MUTATION_PROB = 0.05
NUMBER_OF_OFFSPRINGS = POPULATION_SIZE * CROSSOVER_PROB / 2
NUMBER_OF_EVALUATION = POPULATION_SIZE + (NUMBER_OF_GENERATIONS - 2) * (NUMBER_OF_OFFSPRINGS)
NUMBER_OF_RUNS = 1
PENALTY_COEFFICIENT = 1

def deepgetattr(obj, attr):
    """Recurses through an attribute chain to get the ultimate value."""
    return functools.reduce(getattr, attr.split('.'), obj)


def deepsetattr(obj, attr, val):
    """Recurses through an attribute chain to set the ultimate value."""
    pre, _, post = attr.rpartition('.')
    return setattr(deepgetattr(obj, pre) if pre else obj, post, val)

def nodeParent(nodeID):
    """Return ID of parent of a node"""
    if nodeID > 1:
        return int((nodeID - 1) / 2)
    else:
        return 0


def nodeLeftChild(nodeID):
    """Return ID of left child of a node"""
    return (nodeID * 2) + 1


def nodeRightChild(nodeID):
    """Return ID of right child of a node"""
    return (nodeID * 2) + 2


def totalNumberOfNodes(height):
    """Return total number of nodes in a tree with given height"""
    return 2 ** (height + 1) - 1


class GPTree(object):
    """Objects of genetic programming binary trees"""

    def __init__(self, value=None):
        self.value = value
        self.left = None
        self.right = None
        self.fitness = - float('inf')
        self.evals = 0
        self.normalizedFitness = 0

    def addLeftChild(self, value=None):
        """Add left child to the current node"""
        self.left = GPTree(value)

    def addRightChild(self, value=None):
        """Add right child to the current node"""
        self.right = GPTree(value)

    def getNodeByLocation(self, depth, index):
        """Return the node specified by depth and index"""
        if depth is 0:
            return self
        next = self
        for d in reversed(range(1, depth + 1)):
            if next is not None:
                if index < (2 ** (d - 1)):
                    next = next.left
                else:
                    next = next.right
                index = index % (2 ** (d - 1))
            else:
                return None
        return next

    def getNodeByID(self, id):
        """Return the node specified by its ID"""
        depth = int(math.log(id + 1)/math.log(2))
        index = id - (2 ** depth) + 1
        return self.getNodeByLocation(depth, index)

    def setNodeByLocation(self, depth, index, node):
        """Set the node specified by depth and index"""
        if depth is 0:
            self = node
            return 1
        attr = ''
        next = self
        for d in reversed(range(1, depth + 1)):
            if next is not None:
                if index < (2 ** (d - 1)):
                    next = next.left
                    attr += 'left.'
                else:
                    next = next.right
                    attr += 'right.'
                index = index % (2 ** (d - 1))
                if d is 1:
                    deepsetattr(self, attr[:-1], node)
                    return 1
            else:
                return 0
        return 1

    def setNodeByID(self, id, node):
        """Return the node specified by its ID"""
        depth = int(math.log(id + 1)/math.log(2))
        index = id - (2 ** depth) + 1
        return self.setNodeByLocation(depth, index, node)

    def isNodeNoneByLocation(self, depth, index):
        """Return True/False if the node specified by depth and index is/is not None"""
        node = self.getNodeByLocation(depth, index)
        if node is None:
            return True
        elif node.value is None:
            return True
        else:
            return False

    def isNodeNoneByID(self, id):
        """Return True/False if the node specified by its ID is/is not None"""
        depth = int(math.log(id + 1)/math.log(2))
        index = id - (2 ** depth) + 1
        return self.isNodeNoneByLocation(depth, index)

    def height(self):
        """Returns height of the tree"""
        height = 0
        while True:
            if any(not self.isNodeNoneByLocation(height, index) for index in range(2 ** height)):
                height += 1
            else:
                break
        height -= 1
        return height

    def __str__(self):
        """For simple representation of trees"""
        str_ = ''
        height = self.height()
        for depth in range(height + 1):
            str_ += ' ' * 3 * (2 ** (height - depth) - 1)
            for index in range(2 ** depth):
                if self.isNodeNoneByLocation(depth, index):
                    str_ += '  .  '
                    str_ += ' ' * (3 * (2 ** (height - depth + 1) - 1) - 2)
                elif isinstance(self.getNodeByLocation(depth, index).value, (int, float)):
                    str_ += "{: 5.01f}".format(round(self.getNodeByLocation(depth, index).value, 1))
                    str_ += ' ' * (3 * (2 ** (height - depth + 1) - 1) - 2)
                else:
                    str_ += "{:^5}".format(self.getNodeByLocation(depth, index).value)
                    str_ += ' ' * (3 * (2 ** (height - depth + 1) - 1) - 2)
            str_ += '\n'
        return str_

    def makeTree(self):
        """Populate nodes of an initialized tree by ramped half-and-half method"""

        terminalsSet = PACMAN_TERMINALS
        # Ramped half-and-half initialization
        if random.random() > 0.5:
            # Full method
            for depth in range(MAX_TREE_DEPTH + 1):
                for index in range(2 ** depth):
                    node = self.getNodeByLocation(depth, index)
                    # non terminal node
                    if depth < MAX_TREE_DEPTH:
                        node.value = random.choice(FUNCTIONS)
                        node.addLeftChild()
                        node.addRightChild()
                    # leaf -> terminal node
                    else:
                        node.value = random.choice(terminalsSet)

                    if node.value is CONSTANT:
                        node.value = random.uniform(CONSTANT_MIN, CONSTANT_MAX)
        else:
            # Grow method
            for depth in range(MAX_TREE_DEPTH + 1):
                for index in range(2 ** depth):
                    node = self.getNodeByLocation(depth, index)
                    if depth is 0:
                        node.value = random.choice(FUNCTIONS + terminalsSet)
                        node.addLeftChild()
                        node.addRightChild()
                    else:
                        if depth < MAX_TREE_DEPTH:
                            node.addLeftChild()
                            node.addRightChild()
                            # if node's parent is non-terminal, create child (option to be terminal or not)
                            if self.getNodeByID(nodeParent((2 ** depth) + index - 1)).value in FUNCTIONS:
                                node.value = random.choice(FUNCTIONS + terminalsSet)
                        # max depth - if parents are non-terminal ->creat terminal child
                        elif self.getNodeByID(nodeParent((2 ** depth) + index - 1)).value in FUNCTIONS:
                            node.value = random.choice(terminalsSet)
                    if node.value is CONSTANT:
                        node.value = random.uniform(CONSTANT_MIN, CONSTANT_MAX)