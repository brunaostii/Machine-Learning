# learningAgents.py
# -----------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from game import Directions, Agent, Actions, AgentGP
from keyboardAgents import *
import random,util,time, copy
from gptree import GPTree

import numpy as np
from scipy.spatial.distance import cdist, cityblock


WALL = 0
CANDY = 1
EMPTY = 2
ENEMY = 3
PACMAN_POS = 4

GAME_ON = 0
GAME_OVER = 1

FUNCTIONS = ['+', '-', '*', '/']
DISTANCE_TO_NEAREST_GHOST = 'G'
DISTANCE_TO_NEAREST_PILL = 'P'
PLACE_COUNT = 'T'
CONSTANT = 'C'
PILLS_IN_DISTANCE = 'D'
GHOSTS_IN_DISTANCE = 'E'
DISTANCE_TO_NEAREST_CORNER = 'N'
DISTANCE_TO_NEAREST_POWER = 'O'
PREVENT_MOVEMENT_LOOP = 'L'
CORNER = 'R'

PACMAN_TERMINALS = [DISTANCE_TO_NEAREST_GHOST, DISTANCE_TO_NEAREST_PILL, PLACE_COUNT, PILLS_IN_DISTANCE,
                    GHOSTS_IN_DISTANCE, CONSTANT, DISTANCE_TO_NEAREST_POWER, CORNER, PREVENT_MOVEMENT_LOOP ]
CONSTANT_MIN = -1
CONSTANT_MAX = 10
PRINT = True
# Allowed movements
PACMAN_MOVES = [[0, 1], [0, -1], [1, 0], [-1, 0]]
GHOST_MOVES = [[0, 1], [0, -1], [1, 0], [-1, 0]]

MAX_TREE_DEPTH = 3
TOURNAMENT_SIZE = 3
POPULATION_SIZE = 100
NUMBER_OF_GENERATIONS = 100
CROSSOVER_PROB = 0.7
MUTATION_PROB = 0.05
NUMBER_OF_OFFSPRINGS = POPULATION_SIZE * CROSSOVER_PROB / 2
NUMBER_OF_EVALUATION = POPULATION_SIZE + (NUMBER_OF_GENERATIONS - 2) * (NUMBER_OF_OFFSPRINGS)
NUMBER_OF_RUNS = 1
PENALTY_COEFFICIENT = 1


def deepgetattr(obj, attr):
    """Recurses through an attribute chain to get the ultimate value."""
    return functools.reduce(getattr, attr.split('.'), obj)


def deepsetattr(obj, attr, val):
    """Recurses through an attribute chain to set the ultimate value."""
    pre, _, post = attr.rpartition('.')
    return setattr(deepgetattr(obj, pre) if pre else obj, post, val)


def nodeParent(nodeID):
    """Return ID of parent of a node"""
    if nodeID > 1:
        return int((nodeID - 1) / 2)
    else:
        return 0


def nodeLeftChild(nodeID):
    """Return ID of left child of a node"""
    return (nodeID * 2) + 1


def nodeRightChild(nodeID):
    """Return ID of right child of a node"""
    return (nodeID * 2) + 2


def totalNumberOfNodes(height):
    """Return total number of nodes in a tree with given height"""
    return 2 ** (height + 1) - 1

class ValueEstimationAgent(Agent):
  """
    Abstract agent which assigns values to (state,action)
    Q-Values for an environment. As well as a value to a
    state and a policy given respectively by,

    V(s) = max_{a in actions} Q(s,a)
    policy(s) = arg_max_{a in actions} Q(s,a)

    Both ValueIterationAgent and QLearningAgent inherit
    from this agent. While a ValueIterationAgent has
    a model of the environment via a MarkovDecisionProcess
    (see mdp.py) that is used to estimate Q-Values before
    ever actually acting, the QLearningAgent estimates
    Q-Values while acting in the environment.
  """

  def __init__(self, alpha=1.0, epsilon=0.05, gamma=0.8, numTraining = 10):
    """
    Sets options, which can be passed in via the Pacman command line using -a alpha=0.5,...
    alpha    - learning rate
    epsilon  - exploration rate
    gamma    - discount factor
    numTraining - number of training episodes, i.e. no learning after these many episodes
    """
    self.alpha = float(alpha)
    self.epsilon = float(epsilon)
    self.discount = float(gamma)
    self.numTraining = int(numTraining)

  ####################################
  #    Override These Functions      #
  ####################################
  def getQValue(self, state, action):
    """
    Should return Q(state,action)
    """
    util.raiseNotDefined()

  def getValue(self, state):
    """
    What is the value of this state under the best action?
    Concretely, this is given by

    V(s) = max_{a in actions} Q(s,a)
    """
    util.raiseNotDefined()

  def getPolicy(self, state):
    """
    What is the best action to take in the state. Note that because
    we might want to explore, this might not coincide with getAction
    Concretely, this is given by

    policy(s) = arg_max_{a in actions} Q(s,a)

    If many actions achieve the maximal Q-value,
    it doesn't matter which is selected.
    """
    util.raiseNotDefined()

  def getAction(self, state):
    """
    state: can call state.getLegalActions()
    Choose an action and return it.
    """
    util.raiseNotDefined()

class ReinforcementAgent(ValueEstimationAgent):
  """
    Abstract Reinforcemnt Agent: A ValueEstimationAgent
	  which estimates Q-Values (as well as policies) from experience
	  rather than a model

      What you need to know:
		  - The environment will call
		    observeTransition(state,action,nextState,deltaReward),
		    which will call update(state, action, nextState, deltaReward)
		    which you should override.
      - Use self.getLegalActions(state) to know which actions
		    are available in a state
  """
  ####################################
  #    Override These Functions      #
  ####################################

  def update(self, state, action, nextState, reward):
    """
	    This class will call this function, which you write, after
	    observing a transition and reward
    """
    util.raiseNotDefined()

  ####################################
  #    Read These Functions          #
  ####################################

  def getLegalActions(self,state):
    """
      Get the actions available for a given
      state. This is what you should use to
      obtain legal actions for a state
    """
    return self.actionFn(state)

  def observeTransition(self, state,action,nextState,deltaReward):
    """
    	Called by environment to inform agent that a transition has
    	been observed. This will result in a call to self.update
    	on the same arguments

    	NOTE: Do *not* override or call this function
    """
    self.episodeRewards += deltaReward
    self.update(state,action,nextState,deltaReward)

  def startEpisode(self):
    """
      Called by environment when new episode is starting
    """
    self.lastState = None
    self.lastAction = None
    self.episodeRewards = 0.0

  def stopEpisode(self):
    """
      Called by environment when episode is done
    """
    if self.episodesSoFar < self.numTraining:
		  self.accumTrainRewards += self.episodeRewards
    else:
		  self.accumTestRewards += self.episodeRewards
    self.episodesSoFar += 1
    if self.episodesSoFar >= self.numTraining:
      # Take off the training wheels
      self.epsilon = 0.0    # no exploration
      self.alpha = 0.0      # no learning

  def isInTraining(self):
      return self.episodesSoFar < self.numTraining

  def isInTesting(self):
      return not self.isInTraining()

  def __init__(self, actionFn = None, numTraining=100, epsilon=0.5, alpha=0.5, gamma=1):
    """
    actionFn: Function which takes a state and returns the list of legal actions

    alpha    - learning rate
    epsilon  - exploration rate
    gamma    - discount factor
    numTraining - number of training episodes, i.e. no learning after these many episodes
    """
    if actionFn == None:
        actionFn = lambda state: state.getLegalActions()
    self.actionFn = actionFn
    self.episodesSoFar = 0
    self.accumTrainRewards = 0.0
    self.accumTestRewards = 0.0
    self.numTraining = int(numTraining)
    self.epsilon = float(epsilon)
    self.alpha = float(alpha)
    self.discount = float(gamma)

  ################################
  # Controls needed for Crawler  #
  ################################
  def setEpsilon(self, epsilon):
    self.epsilon = epsilon

  def setLearningRate(self, alpha):
    self.alpha = alpha

  def setDiscount(self, discount):
    self.discount = discount

  def doAction(self,state,action):
    """
        Called by inherited class when
        an action is taken in a state
    """
    self.lastState = state
    self.lastAction = action

  ###################
  # Pacman Specific #
  ###################
  def observationFunction(self, state):
    """
        This is where we ended up after our last action.
        The simulation should somehow ensure this is called
    """
    if not self.lastState is None:
        reward = state.getScore() - self.lastState.getScore()
        self.observeTransition(self.lastState, self.lastAction, state, reward)
    return state

  def registerInitialState(self, state):
    self.startEpisode()
    if self.episodesSoFar == 0:
        print 'Beginning %d episodes of Training' % (self.numTraining)

  def final(self, state):
    """
      Called by Pacman game at the terminal state
    """
    deltaReward = state.getScore() - self.lastState.getScore()
    self.observeTransition(self.lastState, self.lastAction, state, deltaReward)
    self.stopEpisode()

    # Make sure we have this var
    if not 'episodeStartTime' in self.__dict__:
        self.episodeStartTime = time.time()
    if not 'lastWindowAccumRewards' in self.__dict__:
        self.lastWindowAccumRewards = 0.0
    self.lastWindowAccumRewards += state.getScore()

    NUM_EPS_UPDATE = 100
    if self.episodesSoFar % NUM_EPS_UPDATE == 0:
        print 'Reinforcement Learning Status:'
        windowAvg = self.lastWindowAccumRewards / float(NUM_EPS_UPDATE)
        if self.episodesSoFar <= self.numTraining:
            trainAvg = self.accumTrainRewards / float(self.episodesSoFar)
            print '\tCompleted %d out of %d training episodes' % (
                   self.episodesSoFar,self.numTraining)
            print '\tAverage Rewards over all training: %.2f' % (
                    trainAvg)
        else:
            testAvg = float(self.accumTestRewards) / (self.episodesSoFar - self.numTraining)
            print '\tCompleted %d test episodes' % (self.episodesSoFar - self.numTraining)
            print '\tAverage Rewards over testing: %.2f' % testAvg
        print '\tAverage Rewards for last %d episodes: %.2f'  % (
                NUM_EPS_UPDATE,windowAvg)
        print '\tEpisode took %.2f seconds' % (time.time() - self.episodeStartTime)
        self.lastWindowAccumRewards = 0.0
        self.episodeStartTime = time.time()

    if self.episodesSoFar == self.numTraining:
        msg = 'Training Done (turning off epsilon and alpha)'
        print '%s\n%s' % (msg,'-' * len(msg))


class GPAgent(AgentGP):

  def __init__(self, numTraining=0, **args):
    args['numTraining'] = numTraining
    self.numActions = 0
    self.lastAction = [None, None]

  def getAction(self, state, cromossomo):
    self.numActions += 1
    directions = {'West': (-1, 0), 'East': (1, 0) , 'North': (0, 1), 'South':(0,-1), 'Stop': (0,0)}
    
    newStateGoodness = - float('inf')  # very small number
    position = ""
    for direc in state.getLegalActions():
      if self.lastAction[0] == directions[direc] and self.lastAction[1] == tuple(-x for x in directions[direc]):
        continue
      if self.lastAction[1] == tuple(-x for x in directions[direc]) and \
        (self.lastAction[0] == directions['North'] or self.lastAction[0] == directions['South']) and \
          len(state.getLegalActions()) > 2:
        continue
      if direc != 'Stop':
        stateGoodness = self.runTree(cromossomo, state, directions[direc])
        
        if newStateGoodness < stateGoodness:
          newStateGoodness = stateGoodness
          position = direc

    self.lastAction[0] = self.lastAction[1]
    self.lastAction[1] = directions[position]
    return position, self.numActions
    #else:
    #  return Directions.STOP, self.numActions

    #return random.choice(state.getLegalPacmanActions()), self.numActions

  def functionOutput(self, parent, child1, child2):
    """Translate the given function and return its output for provided operands"""
    if parent is '+':
      return (child1 + child2)
    elif parent is '-':
      return (child1 - child2)
    elif parent is '*':
      return (child1 * child2)
    elif parent is '/':
      if child2 == 0:
        return 0
      else:
        return (child1 / child2)

  def runTree(self,tree, state, position):
    """Return the overall output value of a tree"""
    treeCpy = copy.deepcopy(tree)
    height = treeCpy.height()

    for id in reversed(range(totalNumberOfNodes(height))):
      isnone = treeCpy.isNodeNoneByID(id)
      if not treeCpy.isNodeNoneByID(id):
        node = treeCpy.getNodeByID(id)
      
        if node.value is DISTANCE_TO_NEAREST_GHOST:
          node.value = self.DistToNonEdibleGhost(state, position)
        
        elif node.value is DISTANCE_TO_NEAREST_PILL:
          node.value = self.DistToNextPill(state, position)
        
        #elif node.value is DISTANCE_TO_NEAREST_CORNER:
        #  node.value = self.DistToNextCorner(state, position)
      
        elif node.value is PLACE_COUNT:
          node.value = self.DistToEdibleGhost(state, position)

        elif node.value is PILLS_IN_DISTANCE:
          node.value = self.pillsInDistanceK(state, position)

        elif node.value is GHOSTS_IN_DISTANCE:
          node.value = self.ghostsInDistanceK(state, position)

        elif node.value is DISTANCE_TO_NEAREST_POWER:
          try:
            node.value = self.DistToNextPowerPill(state, position)
          except:
            node.value =0
          
        elif node.value is PREVENT_MOVEMENT_LOOP:
          node.value = self.IsMovementInLoop(state)

        elif node.value is CORNER:
          node.value = self.DistToNextJunction(state, position)
        

    for id in reversed(range(totalNumberOfNodes(height))):
      if not treeCpy.isNodeNoneByID(id):
        node = treeCpy.getNodeByID(id)
        if node.value in FUNCTIONS:
          node.value = self.functionOutput(node.value, treeCpy.getNodeByID(nodeLeftChild(id)).value,
                                              treeCpy.getNodeByID(nodeRightChild(id)).value)
    #print node.value
    return node.value

  def IsMovementInLoop(self, state):
    # To stay at the same range of values as the other criteria.
    return - 5 + 5 * sum(state.data._eaten) / len(state.data._eaten)

  def pillsInDistanceK(self, state, position=(0,0)):
    directions = {'West': (-1, 0), 'East': (1, 0) , 'North': (0, 1), 'South':(0,-1)}
    coordinates = self.find_coordinates(np.array(state.getFood().data), True)
    pacman = state.getPacmanPosition()
    aux = 0
    for direct in directions.keys():
      
      pacman_4 = [pacman[0] + directions[direct][0], pacman[1] + directions[direct][1]]

      if pacman_4 in coordinates:
        aux += 1

    return 5* aux  
    
  def ghostsInDistanceK(self, state, position=(0,0)):
    directions = {'West': (-1, 0), 'East': (1, 0) , 'North': (0, 1), 'South':(0,-1)}
    coordinates = np.array(state.getGhostPositions())
    pacman = state.getPacmanPosition()

    aux = 0
    for direct in directions.keys():
      
      pacman_4 = [pacman[0] + directions[direct][0], pacman[1] + directions[direct][1]]

      if pacman_4 in coordinates:
        aux += 1

    return aux  


  def placeCount(self, state, position=(0,0)):
    return state.getNumCapsules()


  def DistToNextPill(self, state, position=(0,0)):
    coordinates = self.find_coordinates(np.array(state.getFood().data), True)
    pacman = (state.getPacmanPosition()[0] + position[0], state.getPacmanPosition()[1] + position[1]) 
    distances = [cityblock(coordinates[i],pacman)for i in range(len(coordinates))]
    return 5 * 1 / (min(distances) + 1)

  def DistToNextPowerPill(self, state, position=(0,0)):
    coordinates = np.array(state.getCapsules())
    pacman = (state.getPacmanPosition()[0] + position[0], state.getPacmanPosition()[1] + position[1]) 
    distances = [cityblock(coordinates[i],pacman)for i in range(len(coordinates))]
    return 5 * 1 / (min(distances) + 1)

  def DistToNonEdibleGhost(self, state, position=(0,0)):
    coordinates = np.array(state.getGhostPositions())
    pacman = (state.getPacmanPosition()[0] + position[0], state.getPacmanPosition()[1] + position[1]) 
    distances = [cityblock(coordinates[i],pacman) for i in range(len(coordinates))]
    return min(distances)

  def DistToEdibleGhost(self, state, position=(0,0)):
    edible = np.array([True if state.data.agentStates[i].scaredTimer > 0 else False for i in range(1, state.getNumAgents())])
    
    if any(edible):
      pacman = (state.getPacmanPosition()[0] + position[0], state.getPacmanPosition()[1] + position[1]) 
      coordinates = state.getGhostPositions()
      distances = [cityblock(coordinates[i],pacman) if j == True else 500000 for i, j in zip(range(len(coordinates)), edible)]
      return 5 * 1 / (min(distances) + 1)

    return 0
  
  def DistToNextCorner(self, state, position=(0,0)):
    get_walls = state.getWalls()
    height = get_walls.height
    width = get_walls.width
    pacman = (state.getPacmanPosition()[0] + position[0], state.getPacmanPosition()[1] + position[1]) 
    walls = self.find_coordinates(np.array(get_walls.data), True)
    corner = [cityblock(walls[i], pacman) if walls[i][0] in [0, width-1] and walls[i][1]  in [0, height-1] else 500000 for i in range(len(walls))]
    
    return min(corner)
    
  def DistToNextJunction(self, state, position=(0,0)):
    get_walls = state.getWalls()
    height = get_walls.height
    width = get_walls.width
    pacman = (state.getPacmanPosition()[0] + position[0], state.getPacmanPosition()[1] + position[1]) 
    walls = self.find_coordinates(np.array(get_walls.data), True)
    corner = [cityblock(walls[i], pacman) if walls[i][0] not in [0, width-1] and walls[i][1] not in [0, height-1] else 500000 for i in range(len(walls))]
    
    return min(corner)



  def find_coordinates(self,array_matrix, value_search):
    line_shape, col_shape = array_matrix.shape
    line, cols = np.where(array_matrix == value_search)
    
    reverse_row = [i for i in range(line_shape)][::-1]
    
    coordinates = []
    for i in range(len(line)):
        coordinates.append([reverse_row[line[i]] ,  cols[i]])
    
    return coordinates



